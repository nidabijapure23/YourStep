export const environment = {
  footwareion: true
};
