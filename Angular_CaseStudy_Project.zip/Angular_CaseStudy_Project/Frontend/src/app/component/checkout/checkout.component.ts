import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/service/cart.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {

  public footwares : any = [];
  public grandTotal !: number;
  constructor(private cartService : CartService) { }

  ngOnInit(): void {
    this.cartService.getfootwares()
    .subscribe(res=>{
      this.footwares = res;
      this.grandTotal = this.cartService.getTotalPrice();
    })
  }
  // removeItem(item: any){
  //   this.cartService.removeCartItem(item);
  // }
  // emptycart(){
  //   this.cartService.removeAllCart();
  // }

}
