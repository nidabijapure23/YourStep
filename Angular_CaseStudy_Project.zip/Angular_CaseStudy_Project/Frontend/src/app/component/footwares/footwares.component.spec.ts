import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FootwaresComponent } from './footwares.component';

describe('FootwaresComponent', () => {
  let component: FootwaresComponent;
  let fixture: ComponentFixture<FootwaresComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FootwaresComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FootwaresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
