import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './component/auth/auth.guard';
import { CartComponent } from './component/cart/cart.component';
import { CheckoutComponent } from './component/checkout/checkout.component';
import { FootwaresComponent } from './component/footwares/footwares.component';
import { SignInComponent } from './component/sign-in/sign-in.component';
import { SignUpComponent } from './component/sign-up/sign-up.component';

const routes: Routes = [
  {path:'', redirectTo:'login',pathMatch:'full'},
  {path:'footwares', component: FootwaresComponent, canActivate:[AuthGuard]},
  {path:'cart', component: CartComponent, canActivate:[AuthGuard]},
  {path:'login', component: SignInComponent},
  {path:'signup', component: SignUpComponent},
  {path:'checkout',component:CheckoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
