import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  public cartItemList : any =[]
  public footwareList = new BehaviorSubject<any>([]);
  public search = new BehaviorSubject<string>("");

  constructor() { }
  getfootwares(){
    return this.footwareList.asObservable();
  }

  setfootware(footware : any){
    this.cartItemList.push(...footware);
    this.footwareList.next(footware);
  }
  addtoCart(footware : any){
    this.cartItemList.push(footware);
    this.footwareList.next(this.cartItemList);
    this.getTotalPrice();
    console.log(this.cartItemList)
  }
  getTotalPrice() : number{
    let grandTotal = 0;
    this.cartItemList.map((a:any)=>{
      grandTotal += a.total;
    })
    return grandTotal;
  }
  removeCartItem(footware: any){
    this.cartItemList.map((a:any, index:any)=>{
      if(footware.id=== a.id){
        this.cartItemList.splice(index,1);
      }
    })
    this.footwareList.next(this.cartItemList);
  }
  removeAllCart(){
    this.cartItemList = []
    this.footwareList.next(this.cartItemList);
  }
}
